
# Part 2, Treemap 2

![Treemap 2](imagepath)

* **Name of Tool**: The tool that was used to generate the treemap
* **Country**: Name of country(s) data shown
* **Year**: the year(s) or time-span of data shown
* **Data Preparation**: A helpful description of how you prepared the data
* **Color**: what is color mapped to?
* **Hierarchy**: What is the data hierarchy contained in the treemap?
* What leaf node size is mapped to?
* How are the leaf nodes laid out or positioned?
* What are internal nodes mapped to?
* What is internal node size mapped to?
* Which treemap node layout algorithm is used? 

