
# Part 1, design 3

![Design 3](pathtofigure.png)

### Description

Visual Design Type: 
: ???

Name of Tool: 
: ???

Country: 
: ???

Year: 
: ???

Visual Mappings:
:   * **mapping 1**: ???
:   * **mapping 2**: ???

Unique Observation: 
: ???
  
Data Preparation:
: ???

