---
title: CSC337/CSCM37 coursework 1
author: Your name here (student number)
...

