
# Part 1, design 1

![Design 1](pathtofigure.png)

### Description

Visual Design Type: 
: ???

Name of Tool: 
: ???

Country: 
: ???

Year: 
: ???

Visual Mappings:
:   * **mapping 1**: ???
:   * **mapping 2**: ???

Unique Observation: 
: ???
  
Data Preparation:
: ???

